document.addEventListener('DOMContentLoaded', () => {
    initializeWizard();
});

function initializeWizard() {
    initializePlatformSelect();
    setupUploadZone();
    setupCharacterCounters();
    setupPreviewUpdates();
    setupFormValidation();
    setupDeviceToggle();
    initializeCarousel();
    initializeTooltips();
    setupHelperText();
    setupDynamicFormFields();
}

function initializePlatformSelect() {
    const platformSelect = document.querySelector('.platform-select');
    const selectedOptions = platformSelect.querySelector('.selected-options');
    const searchInput = platformSelect.querySelector('.platform-search');
    const options = platformSelect.querySelectorAll('.platform-option');
    const dropdownSelect = platformSelect.querySelector('.dropdown-select');

    // Platform data
    const platforms = {
        facebook: { icon: 'facebook', label: 'Facebook' },
        instagram: { icon: 'instagram', label: 'Instagram' },
        linkedin: { icon: 'linkedin', label: 'LinkedIn' }
    };

    // Handle option selection
    options.forEach(option => {
        const checkbox = option.querySelector('input[type="checkbox"]');
        option.addEventListener('click', (e) => {
            e.preventDefault();
            checkbox.checked = !checkbox.checked;
            updateSelectedOptions();
        });
    });

    // Handle search
    searchInput.addEventListener('input', (e) => {
        const searchTerm = e.target.value.toLowerCase();
        options.forEach(option => {
            const text = option.textContent.toLowerCase();
            option.style.display = text.includes(searchTerm) ? 'block' : 'none';
        });
    });

    function updateSelectedOptions() {
        const selected = Array.from(options)
            .filter(option => option.querySelector('input[type="checkbox"]').checked)
            .map(option => option.dataset.value);

        // Update selected options display
        selectedOptions.innerHTML = selected.map(value => {
            const platform = platforms[value];
            return `
                <span class="selected-option">
                    <i class="bi bi-${platform.icon}"></i>
                    ${platform.label}
                    <i class="bi bi-x remove" data-value="${value}"></i>
                </span>
            `;
        }).join('');

        // Update dropdown class
        dropdownSelect.classList.toggle('has-value', selected.length > 0);

        // Add remove handlers
        selectedOptions.querySelectorAll('.remove').forEach(btn => {
            btn.addEventListener('click', (e) => {
                e.stopPropagation();
                const value = btn.dataset.value;
                const checkbox = platformSelect.querySelector(`#${value}`);
                checkbox.checked = false;
                updateSelectedOptions();
            });
        });

        // Update form state
        updateFormState();
    }

    // Initialize
    updateSelectedOptions();
}

function setupUploadZone() {
    const fileInput = document.getElementById('fileInput');
    const uploadList = document.getElementById('uploadList');
    const uploadZone = document.getElementById('uploadZone');
    const browseButton = uploadZone.querySelector('button');

    // Update requirements list based on selected platforms
    function updateRequirementsList() {
        const selectedPlatforms = Array.from(document.querySelectorAll('.platform-option input:checked')).map(input => input.id);
        const adType = document.getElementById('adType').value;
        const requirementsList = document.querySelector('.requirements-list');

        const requirements = selectedPlatforms.map(platform => {
            const type = AD_TYPES[platform].find(t => t.value === adType) || AD_TYPES[platform][0];
            return `<div class="requirement-item">
                <span class="platform-name">${platform}:</span>
                <span class="dimensions">${type.dimensions}</span>
            </div>`;
        });

        requirementsList.innerHTML = requirements.join('');
    }

    // Update requirements when platforms or ad type changes
    document.querySelectorAll('.platform-option input, #adType').forEach(input => {
        input.addEventListener('change', updateRequirementsList);
    });

    // Handle browse button click
    browseButton.addEventListener('click', () => {
        fileInput.click();
    });

    // Handle file selection
    fileInput.addEventListener('change', (e) => {
        const files = e.target.files;
        if (!files.length) return;

        handleFiles(files);

        // Reset input
        e.target.value = '';
    });

    function handleFiles(files) {
        Array.from(files).forEach(async file => {
            if (validateFile(file)) {
                if (file.type.startsWith('video/')) {
                    createVideoPreview(file);
                } else {
                    createImagePreview(file);
                }
            }
        });
    }

    function createVideoPreview(file) {
        const reader = new FileReader();
        reader.onload = (e) => {
            const item = document.createElement('div');
            item.className = 'upload-item video';
            const fileType = file.type === 'video/quicktime' ? 'MOV' : 'MP4';
            item.innerHTML = `
                <div class="upload-item-preview">
                    <video src="${e.target.result}" muted>
                        Your browser does not support the video tag.
                    </video>
                    <div class="video-overlay">
                        <i class="bi bi-play-circle"></i>
                        <span class="video-duration"></span>
                    </div>
                </div>
                <div class="upload-item-info">
                    <div class="upload-item-name">${file.name}</div>
                    <div class="upload-item-meta">
                        <span class="upload-item-size">${formatFileSize(file.size)}</span>
                        <span class="upload-item-type">${fileType}</span>
                    </div>
                </div>
                <button type="button" class="delete-file" title="Delete">
                    <i class="bi bi-trash"></i>
                </button>
            `;

            // Get video duration
            const video = item.querySelector('video');
            video.onloadedmetadata = () => {
                const duration = Math.round(video.duration);
                const minutes = Math.floor(duration / 60);
                const seconds = duration % 60;
                item.querySelector('.video-duration').textContent = 
                    `${minutes}:${seconds.toString().padStart(2, '0')}`;
            };

            // Add play/pause functionality
            const overlay = item.querySelector('.video-overlay');
            overlay.addEventListener('click', () => {
                if (video.paused) {
                    video.play();
                    overlay.classList.add('playing');
                } else {
                    video.pause();
                    overlay.classList.remove('playing');
                }
            });

            // Reset overlay when video ends
            video.addEventListener('ended', () => {
                overlay.classList.remove('playing');
            });

            // Add delete handler
            item.querySelector('.delete-file').addEventListener('click', () => {
                item.remove();
                updateFormState();
            });

            uploadList.appendChild(item);
            updateFormState();
        };
        reader.readAsDataURL(file);
    }

    function createImagePreview(file) {
        const reader = new FileReader();
        reader.onload = (e) => {
            const item = document.createElement('div');
            item.className = 'upload-item image';
            item.innerHTML = `
                <div class="upload-item-preview">
                    <img src="${e.target.result}" alt="${file.name}">
                </div>
                <div class="upload-item-info">
                    <div class="upload-item-name">${file.name}</div>
                    <div class="upload-item-meta">
                        <span class="upload-item-size">${formatFileSize(file.size)}</span>
                        <span class="upload-item-type">${file.type.split('/')[1].toUpperCase()}</span>
                    </div>
                </div>
                <button type="button" class="delete-file" title="Delete">
                    <i class="bi bi-trash"></i>
                </button>
            `;

            // Add delete handler
            item.querySelector('.delete-file').addEventListener('click', () => {
                item.remove();
                updateFormState();
            });

            uploadList.appendChild(item);
            updateFormState();
        };
        reader.readAsDataURL(file);
    }

    function formatFileSize(bytes) {
        if (bytes === 0) return '0 Bytes';
        const k = 1024;
        const sizes = ['Bytes', 'KB', 'MB'];
        const i = Math.floor(Math.log(bytes) / Math.log(k));
        return parseFloat((bytes / Math.pow(k, i)).toFixed(2)) + ' ' + sizes[i];
    }
}

function setupCharacterCounters() {
    const headline = document.getElementById('headline');
    const description = document.getElementById('description');
    const headlineCount = document.getElementById('headlineCount');
    const descriptionCount = document.getElementById('descriptionCount');

    function updateCount(element, counter) {
        counter.textContent = element.value.length;
        if (element.value.length >= parseInt(element.maxLength) * 0.9) {
            counter.classList.add('text-danger');
        } else {
            counter.classList.remove('text-danger');
        }
    }

    headline.addEventListener('input', () => updateCount(headline, headlineCount));
    description.addEventListener('input', () => updateCount(description, descriptionCount));
}

function setupPreviewUpdates() {
    const inputs = document.querySelectorAll('input, textarea, select');
    inputs.forEach(input => {
        input.addEventListener('change', updatePreview);
        if (input.tagName === 'TEXTAREA' || input.type === 'text') {
            input.addEventListener('input', updatePreview);
        }
    });
}

function updatePreview() {
    const data = collectFormData();
    const previewFrames = document.querySelectorAll('.preview-frame');

    previewFrames.forEach(frame => {
        if (frame.classList.contains('facebook')) {
            updateFacebookPreview(frame, data);
        } else if (frame.classList.contains('instagram')) {
            updateInstagramPreview(frame, data);
        } else if (frame.classList.contains('linkedin')) {
            updateLinkedInPreview(frame, data);
        }
    });

    // Initialize carousel after updating previews
    initializeCarousel();
}

function setupFormValidation() {
    const form = document.querySelector('.wizard-container');
    const submitBtn = document.getElementById('submit');
    const saveDraftBtn = document.getElementById('saveDraft');

    submitBtn.addEventListener('click', (e) => {
        e.preventDefault();
        if (validateForm()) {
            // Handle form submission
            console.log('Form submitted:', collectFormData());
        }
    });

    saveDraftBtn.addEventListener('click', (e) => {
        e.preventDefault();
        // Handle draft saving
        console.log('Draft saved:', collectFormData());
    });
}

// Utility Functions
function formatFileSize(bytes) {
    if (bytes === 0) return '0 Bytes';
    const k = 1024;
    const sizes = ['Bytes', 'KB', 'MB', 'GB'];
    const i = Math.floor(Math.log(bytes) / Math.log(k));
    return parseFloat((bytes / Math.pow(k, i)).toFixed(2)) + ' ' + sizes[i];
}

function showWarning(message) {
    const warningsContainer = document.createElement('div');
    warningsContainer.className = 'alert alert-warning alert-dismissible fade show';
    warningsContainer.innerHTML = `
        <i class="bi bi-exclamation-triangle-fill me-2"></i>
        ${message}
        <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button>
    `;

    // Insert warning at the top of the upload section
    const uploadSection = document.querySelector('.upload-section');
    uploadSection.insertBefore(warningsContainer, uploadSection.firstChild);

    // Auto dismiss after 3 seconds
    setTimeout(() => {
        warningsContainer.remove();
    }, 3000);
}

function validateForm() {
    // Add your form validation logic here
    return true;
}

function collectFormData() {
    return {
        platforms: Array.from(document.querySelectorAll('.platform-option input:checked')).map(p => p.id),
        adType: document.getElementById('adType').value,
        headline: document.getElementById('headline').value,
        description: document.getElementById('description').value,
        cta: document.getElementById('cta').value,
        url: document.getElementById('url').value,
        files: Array.from(document.querySelectorAll('.upload-item')).map(item => {
            const img = item.querySelector('img');
            const video = item.querySelector('video');
            return {
                name: item.querySelector('.upload-item-name').textContent,
                preview: img ? img.src : (video ? video.src : ''),
                type: img ? 'image' : 'video'
            };
        })
    };
}

function updateFormState() {
    // Get all form data
    const formData = {
        platforms: Array.from(document.querySelectorAll('.platform-option input:checked')).map(input => input.id),
        adType: document.getElementById('adType').value,
        files: Array.from(document.querySelectorAll('.upload-item')),
        headline: document.getElementById('headline')?.value,
        description: document.getElementById('description')?.value,
        cta: document.getElementById('cta')?.value,
        url: document.getElementById('url')?.value
    };

    // Update Ad Type options based on selected platforms
    updateAdTypeOptions(formData.platforms);

    // Update preview tabs based on selected platforms
    updatePreviewTabs();

    // Enable/disable submit button based on required fields
    const submitBtn = document.getElementById('submit');
    if (submitBtn) {
        submitBtn.disabled = !validateFormData(formData);
    }
}

function validateFormData(formData) {
    if (!formData.platforms.length) {
        showWarning('Please select at least one platform');
        return false;
    }

    if (!formData.adType) {
        showWarning('Please select an ad type');
        return false;
    }

    if (!formData.files.length) {
        showWarning('Please upload at least one media file');
        return false;
    }

    // Validate required fields based on platform and ad type
    if (!formData.headline && needsHeadline(formData.platforms)) {
        showWarning('Headline is required for the selected platforms');
        return false;
    }

    if (!formData.description && needsDescription(formData.platforms)) {
        showWarning('Description is required for the selected platforms');
        return false;
    }

    return true;
}

function needsHeadline(platforms) {
    return platforms.some(p => ['facebook', 'linkedin'].includes(p));
}

function needsDescription(platforms) {
    return platforms.some(p => ['facebook', 'instagram', 'linkedin'].includes(p));
}

// Add this constant at the top level
const AD_TYPES = {
    facebook: [
        { value: 'single_image', label: 'Single Image', dimensions: '1080x1080' },
        { value: 'video', label: 'Video', dimensions: '1080x1080' },
        { value: 'carousel', label: 'Carousel', dimensions: '1080x1080' }
    ],
    instagram: [
        { value: 'single_image', label: 'Single Image', dimensions: '1080x1080' },
        { value: 'video', label: 'Video', dimensions: '1080x1080' },
        { value: 'carousel', label: 'Carousel', dimensions: '1080x1080' },
        { value: 'story', label: 'Story', dimensions: '1080x1920' },
        { value: 'reel', label: 'Reel', dimensions: '1080x1920' }
    ],
    linkedin: [
        { value: 'single_image', label: 'Single Image', dimensions: '1200x627' },
        { value: 'video', label: 'Video', dimensions: '1200x627' },
        { value: 'carousel', label: 'Carousel', dimensions: '1200x627' }
    ]
};

// Update the updateAdTypeOptions function
function updateAdTypeOptions(selectedPlatforms) {
    const adTypeSelect = document.getElementById('adType');
    if (!adTypeSelect || !selectedPlatforms.length) {
        return;
    }

    // Get common ad types across selected platforms
    const commonAdTypes = getCommonAdTypes(selectedPlatforms);

    // Update select options with platform information
    adTypeSelect.innerHTML = `
        <option value="">Select Ad Type</option>
        ${commonAdTypes.map(type => `
            <option value="${type.value}" 
                    data-dimensions="${type.dimensions}"
                    data-platforms="${type.platforms.join(', ')}">
                ${type.label} (${type.platforms.join(', ')})
            </option>
        `).join('')}
    `;

    // Add tooltip to show dimensions
    const tooltip = new bootstrap.Tooltip(adTypeSelect, {
        title: () => {
            const selected = adTypeSelect.options[adTypeSelect.selectedIndex];
            if (selected.value) {
                return `Required dimensions: ${selected.dataset.dimensions}
                        Supported by: ${selected.dataset.platforms}`;
            }
            return 'Select an ad type';
        },
        placement: 'right',
        trigger: 'hover focus'
    });
}

// Helper function to get common ad types
function getCommonAdTypes(selectedPlatforms) {
    // Get all ad types for first platform
    let commonTypes = AD_TYPES[selectedPlatforms[0]].map(type => ({
        ...type,
        platforms: [selectedPlatforms[0]]
    }));

    // Filter based on other platforms
    if (selectedPlatforms.length > 1) {
        commonTypes = commonTypes.filter(type => {
            const supportedPlatforms = selectedPlatforms.filter(platform => 
                AD_TYPES[platform].some(t => t.value === type.value)
            );
            type.platforms = supportedPlatforms;
            return supportedPlatforms.length === selectedPlatforms.length;
        });
    }

    return commonTypes;
}

// Update the validateFile function to check dimensions
function validateFile(file) {
    const validImageTypes = ['image/jpeg', 'image/png'];
    const validVideoTypes = ['video/mp4', 'video/quicktime'];
    const maxImageSize = 5 * 1024 * 1024; // 5MB
    const maxVideoSize = 100 * 1024 * 1024; // 100MB
    const maxVideoDuration = 60; // 60 seconds

    if (file.type.startsWith('image/')) {
        if (!validImageTypes.includes(file.type)) {
            showWarning('Please upload JPG or PNG images only');
            return false;
        }
        if (file.size > maxImageSize) {
            showWarning('Image size should not exceed 5MB');
            return false;
        }
    } else if (file.type.startsWith('video/')) {
        if (!validVideoTypes.includes(file.type)) {
            showWarning('Please upload MP4 or MOV videos only');
            return false;
        }
        if (file.size > maxVideoSize) {
            showWarning('Video size should not exceed 100MB');
            return false;
        }

        // Check video duration
        return new Promise((resolve) => {
            const video = document.createElement('video');
            video.preload = 'metadata';
            video.onloadedmetadata = () => {
                URL.revokeObjectURL(video.src);
                if (video.duration > maxVideoDuration) {
                    showWarning(`Video duration should not exceed ${maxVideoDuration} seconds`);
                    resolve(false);
                }
                resolve(true);
            };
            video.src = URL.createObjectURL(file);
        });
    } else {
        showWarning('Unsupported file type');
        return false;
    }

    return true;
}

// Helper function to get dimension requirements
function getDimensionRequirements(selectedPlatforms, adType) {
    return selectedPlatforms.map(platform => {
        const type = AD_TYPES[platform].find(t => t.value === adType);
        return {
            platform,
            dimensions: type.dimensions
        };
    });
}

// Helper function to validate dimensions
function validateDimensions(width, height, requirements) {
    return requirements.every(req => {
        const [reqWidth, reqHeight] = req.dimensions.split('x').map(Number);
        const ratio = width / height;
        const reqRatio = reqWidth / reqHeight;
        
        // Allow some flexibility (within 1% of required ratio)
        return Math.abs(ratio - reqRatio) < 0.01;
    });
}

// Add these preview functions
function updateFacebookPreview(frame, data) {
    const adTypeTemplate = getFacebookAdTypeTemplate(data.adType, data);
    frame.innerHTML = `
        <div class="fb-preview">
            <div class="preview-header">
                <div class="page-info">
                    <div class="page-name">Your Page</div>
                    <div class="post-meta">Sponsored · <i class="bi bi-globe"></i></div>
                </div>
            </div>
            ${adTypeTemplate}
        </div>
    `;
}

function getFacebookAdTypeTemplate(adType, data) {
    switch(adType) {
        case 'video':
            const videoFile = data.files.find(f => f.type === 'video');
            return `
                <div class="preview-video">
                    <div class="video-container">
                        ${videoFile ? 
                            `<video src="${videoFile.preview}" controls>
                                Your browser does not support video playback
                            </video>` : 
                            '<div class="placeholder">No video selected</div>'
                        }
                    </div>
                    <div class="preview-content">
                        <div class="headline">${data.headline || 'Your headline here'}</div>
                        <div class="description">${data.description || 'Your description here'}</div>
                        <div class="cta-button">${data.cta || 'Learn More'}</div>
                    </div>
                </div>
            `;
        case 'carousel':
            // Get all carousel cards data
            const carouselCards = Array.from(document.querySelectorAll('.carousel-card')).map(card => ({
                headline: card.querySelector('input[type="text"]').value,
                description: card.querySelector('textarea').value,
                url: card.querySelector('input[type="url"]').value
            }));

            // If no cards added yet, show placeholder
            if (carouselCards.length === 0) {
                return `
                    <div class="preview-carousel">
                        <div class="carousel-container">
                            <div class="placeholder">Add carousel cards to preview</div>
                        </div>
                    </div>
                `;
            }

            // Create carousel with cards
            return `
                <div class="preview-carousel">
                    <div class="carousel-container">
                        ${data.files.map((file, index) => `
                            <div class="carousel-item ${index === 0 ? 'active' : ''}">
                                ${file.type === 'video' ?
                                    `<video src="${file.preview}" controls>
                                        Your browser does not support video playback
                                    </video>` :
                                    `<img src="${file.preview}" alt="Preview ${index + 1}">`
                                }
                                <div class="carousel-content">
                                    <div class="headline">${carouselCards[index]?.headline || 'Add headline'}</div>
                                    <div class="description">${carouselCards[index]?.description || 'Add description'}</div>
                                    <div class="cta-button">${data.cta || 'Learn More'}</div>
                                </div>
                            </div>
                        `).join('')}
                        ${data.files.length > 1 ? `
                            <button class="carousel-control prev">
                                <i class="bi bi-chevron-left"></i>
                            </button>
                            <button class="carousel-control next">
                                <i class="bi bi-chevron-right"></i>
                            </button>
                            <div class="carousel-indicators">
                                ${data.files.map((_, index) => `
                                    <span class="indicator ${index === 0 ? 'active' : ''}"
                                          data-index="${index}"></span>
                                `).join('')}
                            </div>
                        ` : ''}
                    </div>
                </div>
            `;
        default: // single_image
            const imageFile = data.files.find(f => f.type === 'image');
            return `
                <div class="preview-media">
                    ${imageFile ? 
                        `<img src="${imageFile.preview}" alt="Preview">` : 
                        '<div class="placeholder">No media selected</div>'
                    }
                </div>
                <div class="preview-content">
                    <div class="headline">${data.headline || 'Your headline here'}</div>
                    <div class="description">${data.description || 'Your description here'}</div>
                    <div class="cta-button">${data.cta || 'Learn More'}</div>
                </div>
            `;
    }
}

function updateInstagramPreview(frame, data) {
    const mediaFile = data.files[0];
    frame.innerHTML = `
        <div class="ig-preview">
            <div class="preview-header">
                <div class="profile-pic">
                    <img src="images/default-profile.png" alt="Profile">
                </div>
                <div class="profile-info">
                    <div class="profile-name">Your Profile</div>
                    <div class="post-meta">Sponsored</div>
                </div>
                <div class="header-actions">
                    <i class="bi bi-three-dots"></i>
                </div>
            </div>
            <div class="preview-media">
                ${mediaFile ? 
                    mediaFile.type === 'video' ?
                        `<video src="${mediaFile.preview}" controls>
                            Your browser does not support video playback
                        </video>` :
                        `<img src="${mediaFile.preview}" alt="Preview">` :
                    '<div class="placeholder">No media selected</div>'
                }
            </div>
            <div class="preview-actions">
                <div class="action-buttons">
                    <i class="bi bi-heart"></i>
                    <i class="bi bi-chat"></i>
                    <i class="bi bi-send"></i>
                    <i class="bi bi-bookmark ms-auto"></i>
                </div>
                <div class="likes">89 views</div>
            </div>
            <div class="preview-content">
                <div class="caption">
                    <span class="profile-name">Your Profile</span>
                    ${data.description || 'Your caption here'}
                </div>
                <div class="view-comments">View all 14 comments</div>
                <div class="post-time">1 HOUR AGO</div>
            </div>
            <div class="preview-footer">
                <div class="cta-button">${data.cta || 'Download'}</div>
            </div>
        </div>
    `;
}

function updateLinkedInPreview(frame, data) {
    const mediaFile = data.files[0];
    const mediaPreview = mediaFile ? 
        mediaFile.type === 'video' ?
            `<video src="${mediaFile.preview}" controls>
                Your browser does not support video playback
            </video>` :
            `<img src="${mediaFile.preview}" alt="Preview">` :
        '<div class="placeholder">No media selected</div>';

    frame.innerHTML = `
        <div class="li-preview">
            <div class="preview-header small">
                <div class="profile-info">
                    <div class="profile-pic profile-fallback small">JD</div>
                    <div class="profile-meta">
                        <span class="profile-name">John Doe</span>
                        <span class="follows-text">follows</span>
                        <span class="company-link">Company Name</span>
                    </div>
                </div>
                <div class="header-actions">
                    <i class="bi bi-three-dots"></i>
                </div>
            </div>
            <div class="company-section">
                <div class="company-logo company-fallback">CN</div>
                <div class="company-info">
                    <div class="company-name">Company Name</div>
                    <div class="followers">36,276 followers</div>
                    <div class="promoted">Promoted</div>
                </div>
            </div>
            <div class="post-content">
                ${data.description || 'Want to achieve a 249% ROI through your cybersecurity? Strengthen your organization\'s security with Kudelski Security\'s transformative MDR'} 
                <span class="see-more">...more</span>
            </div>
            <div class="preview-media">
                ${mediaPreview}
            </div>
            <div class="post-title">
                ${data.headline || 'Download the Full Forrester Report'}
            </div>
            <div class="post-stats">104 submits</div>
            <div class="engagement">
                <div class="reactions">
                    <div class="reaction-icons">
                        <span class="like">👍</span>
                        <span class="celebrate"></span>
                        <span class="love">❤️</span>
                    </div>
                    155
                </div>
                <div class="comments-reposts">
                    6 comments • 12 reposts
                </div>
            </div>
            <div class="action-buttons">
                <button class="action-btn">
                    <i class="bi bi-hand-thumbs-up"></i>
                    Like
                </button>
                <button class="action-btn">
                    <i class="bi bi-chat-text"></i>
                    Comment
                </button>
                <button class="action-btn">
                    <i class="bi bi-arrow-repeat"></i>
                    Repost
                </button>
                <button class="action-btn">
                    <i class="bi bi-send"></i>
                    Send
                </button>
            </div>
        </div>
    `;
}

// Add this function to handle dynamic preview tabs
function updatePreviewTabs() {
    const selectedPlatforms = Array.from(document.querySelectorAll('.platform-option input:checked')).map(input => input.id);
    const previewContainer = document.querySelector('.preview-content');
    const tabsContainer = document.querySelector('.nav-tabs');
    const currentDevice = document.querySelector('.device-toggle button.active').dataset.device;
    
    // Generate tabs
    tabsContainer.innerHTML = selectedPlatforms.map((platform, index) => `
        <li class="nav-item" role="presentation">
            <button class="nav-link ${index === 0 ? 'active' : ''}" 
                    data-bs-toggle="tab" 
                    data-bs-target="#${platform}Preview" 
                    type="button" 
                    role="tab">
                <i class="bi bi-${platform}"></i>
                ${platform.charAt(0).toUpperCase() + platform.slice(1)}
            </button>
        </li>
    `).join('');

    // Generate preview panes
    previewContainer.innerHTML = selectedPlatforms.map((platform, index) => `
        <div class="tab-pane fade ${index === 0 ? 'show active' : ''}" 
             id="${platform}Preview" 
             role="tabpanel">
            <div class="preview-frame ${platform} ${currentDevice}"></div>
        </div>
    `).join('');

    // Initialize previews
    updatePreview();
}

function setupDeviceToggle() {
    const toggleButtons = document.querySelectorAll('.device-toggle button');
    const previewFrame = document.querySelector('.preview-frame');

    toggleButtons.forEach(button => {
        button.addEventListener('click', () => {
            // Update active state
            toggleButtons.forEach(btn => btn.classList.remove('active'));
            button.classList.add('active');

            // Update preview mode
            const device = button.dataset.device;
            const previewFrames = document.querySelectorAll('.preview-frame');
            
            previewFrames.forEach(frame => {
                frame.classList.remove('mobile', 'desktop');
                frame.classList.add(device);
            });

            // Update previews
            updatePreview();
        });
    });
}

function initializeCarousel() {
    document.querySelectorAll('.preview-carousel').forEach(carousel => {
        const items = carousel.querySelectorAll('.carousel-item');
        const indicators = carousel.querySelectorAll('.indicator');
        const prevBtn = carousel.querySelector('.prev');
        const nextBtn = carousel.querySelector('.next');
        let currentIndex = 0;

        if (items.length <= 1) return; // Don't initialize for single item

        function showSlide(index) {
            // Hide all items
            items.forEach(item => {
                item.style.opacity = '0';
                item.classList.remove('active');
            });
            indicators.forEach(ind => ind.classList.remove('active'));

            // Show selected item
            setTimeout(() => {
                items[index].style.opacity = '1';
                items[index].classList.add('active');
                indicators[index].classList.add('active');
            }, 150);
        }

        // Add click handlers
        prevBtn?.addEventListener('click', (e) => {
            e.preventDefault();
            currentIndex = (currentIndex - 1 + items.length) % items.length;
            showSlide(currentIndex);
        });

        nextBtn?.addEventListener('click', (e) => {
            e.preventDefault();
            currentIndex = (currentIndex + 1) % items.length;
            showSlide(currentIndex);
        });

        indicators.forEach((indicator, index) => {
            indicator.addEventListener('click', (e) => {
                e.preventDefault();
                currentIndex = index;
                showSlide(currentIndex);
            });
        });

        // Add swipe support
        let touchStartX = 0;
        let touchEndX = 0;

        carousel.addEventListener('touchstart', (e) => {
            touchStartX = e.changedTouches[0].screenX;
        }, false);

        carousel.addEventListener('touchend', (e) => {
            touchEndX = e.changedTouches[0].screenX;
            handleSwipe();
        }, false);

        function handleSwipe() {
            const swipeThreshold = 50;
            if (touchEndX < touchStartX - swipeThreshold) {
                // Swipe left
                currentIndex = (currentIndex + 1) % items.length;
                showSlide(currentIndex);
            }
            if (touchEndX > touchStartX + swipeThreshold) {
                // Swipe right
                currentIndex = (currentIndex - 1 + items.length) % items.length;
                showSlide(currentIndex);
            }
        }
    });
}

function initializeTooltips() {
    const tooltips = document.querySelectorAll('[data-bs-toggle="tooltip"]');
    tooltips.forEach(tooltip => {
        new bootstrap.Tooltip(tooltip, {
            trigger: 'hover focus'
        });
    });
}

function setupHelperText() {
    // Update Ad Type helper text when selection changes
    const adTypeSelect = document.getElementById('adType');
    const adTypeHelper = document.getElementById('adTypeHelper');

    adTypeSelect.addEventListener('change', () => {
        const selected = adTypeSelect.options[adTypeSelect.selectedIndex];
        if (selected.value) {
            const platforms = selected.dataset.platforms;
            const dimensions = selected.dataset.dimensions;
            
            adTypeHelper.innerHTML = `
                <div class="ad-type-helper">
                    <div class="description">
                        ${getAdTypeDescription(selected.value)}
                    </div>
                    <div class="specs">
                        <div class="spec-item">
                            <i class="bi bi-rulers"></i>
                            ${dimensions}
                        </div>
                        <div class="spec-item">
                            <i class="bi bi-display"></i>
                            ${platforms}
                        </div>
                        ${getAdTypeSpecs(selected.value)}
                    </div>
                </div>
            `;
        } else {
            adTypeHelper.innerHTML = '';
        }
    });
}

function getAdTypeDescription(type) {
    const descriptions = {
        single_image: 'Single image ads are perfect for showcasing your product or message with a clear, focused visual.',
        video: 'Video ads help you tell your story and engage viewers with motion and sound.',
        carousel: 'Carousel ads let you show multiple images or videos that users can swipe through.',
        story: 'Story ads appear in full-screen format, perfect for immersive experiences.',
        reel: 'Reel ads help you reach audiences with short-form, entertaining videos.'
    };
    return descriptions[type] || '';
}

function getAdTypeSpecs(type) {
    const specs = {
        single_image: `
            <div class="spec-item">
                <i class="bi bi-file-image"></i>
                JPG, PNG
            </div>
            <div class="spec-item">
                <i class="bi bi-hdd"></i>
                Max 5MB
            </div>
        `,
        video: `
            <div class="spec-item">
                <i class="bi bi-camera-video"></i>
                MP4, MOV
            </div>
            <div class="spec-item">
                <i class="bi bi-clock"></i>
                Max 60s
            </div>
            <div class="spec-item">
                <i class="bi bi-hdd"></i>
                Max 100MB
            </div>
        `,
        carousel: `
            <div class="spec-item">
                <i class="bi bi-images"></i>
                2-10 items
            </div>
        `
    };
    return specs[type] || '';
}

// Add these constants at the top level
const PLATFORM_LIMITS = {
    facebook: {
        headline: 40,
        description: 125
    },
    instagram: {
        headline: 0, // Optional
        description: 2200
    },
    linkedin: {
        headline: 70,
        description: 150
    }
};

const CTA_OPTIONS = {
    facebook: ['Learn More', 'Shop Now', 'Sign Up', 'Download', 'Contact Us'],
    instagram: ['Learn More', 'Shop Now', 'Sign Up', 'Book Now', 'Download'],
    linkedin: ['Learn More', 'Sign Up', 'Subscribe', 'Register', 'Download']
};

// Add this function to handle dynamic form fields
function setupDynamicFormFields() {
    const adTypeSelect = document.getElementById('adType');
    const fieldGroups = document.querySelectorAll('.field-group');
    const platformLimits = document.querySelectorAll('.platform-limits span');
    const ctaSelect = document.getElementById('cta');

    // Handle Ad Type change
    adTypeSelect.addEventListener('change', () => {
        const selectedType = adTypeSelect.value;
        
        // Hide all field groups
        fieldGroups.forEach(group => {
            group.style.display = 'none';
        });

        // Show selected type fields
        if (selectedType) {
            const selectedGroup = document.querySelector(`.field-group[data-ad-type="${selectedType}"]`);
            if (selectedGroup) {
                selectedGroup.style.display = 'block';
            }
        }

        updateFormState();
    });

    // Update character limits based on selected platforms
    function updateCharacterLimits() {
        const selectedPlatforms = Array.from(document.querySelectorAll('.platform-option input:checked')).map(input => input.id);
        
        // Hide all platform limits
        platformLimits.forEach(limit => {
            limit.style.display = 'none';
        });

        // Show relevant platform limits
        selectedPlatforms.forEach(platform => {
            const limits = document.querySelectorAll(`.platform-limits .${platform}`);
            limits.forEach(limit => {
                limit.style.display = 'inline-block';
            });
        });

        // Update max lengths
        updateMaxLengths(selectedPlatforms);
    }

    // Update input max lengths based on selected platforms
    function updateMaxLengths(platforms) {
        const headline = document.getElementById('headline');
        const description = document.getElementById('description');

        if (platforms.length === 0) {
            headline.maxLength = 40; // Default
            description.maxLength = 125; // Default
            return;
        }

        // Find the minimum limit among selected platforms
        const headlineLimit = Math.min(...platforms.map(p => PLATFORM_LIMITS[p].headline).filter(l => l > 0));
        const descriptionLimit = Math.min(...platforms.map(p => PLATFORM_LIMITS[p].description));

        headline.maxLength = headlineLimit;
        description.maxLength = descriptionLimit;

        // Update counter displays
        document.getElementById('headlineCount').parentElement.textContent = 
            `${headline.value.length}/${headlineLimit}`;
        document.getElementById('descriptionCount').parentElement.textContent = 
            `${description.value.length}/${descriptionLimit}`;
    }

    // Update CTA options based on selected platforms
    function updateCTAOptions() {
        const selectedPlatforms = Array.from(document.querySelectorAll('.platform-option input:checked')).map(input => input.id);
        
        if (selectedPlatforms.length === 0) {
            ctaSelect.innerHTML = '<option value="">Select CTA</option>';
            return;
        }

        // Get common CTAs across selected platforms
        const commonCTAs = selectedPlatforms.reduce((common, platform) => {
            if (common.length === 0) return CTA_OPTIONS[platform];
            return common.filter(cta => CTA_OPTIONS[platform].includes(cta));
        }, []);

        // Update select options
        ctaSelect.innerHTML = `
            <option value="">Select CTA</option>
            ${commonCTAs.map(cta => `
                <option value="${cta.toLowerCase().replace(/\s+/g, '_')}">${cta}</option>
            `).join('')}
        `;
    }

    // Add carousel card functionality
    const addCardBtn = document.getElementById('addCard');
    const carouselCards = document.getElementById('carouselCards');

    if (addCardBtn) {
        addCardBtn.addEventListener('click', () => {
            const cardCount = carouselCards.children.length;
            if (cardCount >= 10) {
                showWarning('Maximum 10 cards allowed');
                return;
            }

            const cardHtml = `
                <div class="carousel-card mb-3">
                    <div class="card">
                        <div class="card-header d-flex justify-content-between align-items-center">
                            <h6 class="mb-0">Card ${cardCount + 1}</h6>
                            <button type="button" class="btn-close" aria-label="Remove card"></button>
                        </div>
                        <div class="card-body">
                            <div class="mb-3">
                                <label class="form-label">Headline</label>
                                <input type="text" class="form-control" maxlength="40">
                            </div>
                            <div class="mb-3">
                                <label class="form-label">Description</label>
                                <textarea class="form-control" rows="2" maxlength="125"></textarea>
                            </div>
                            <div class="mb-3">
                                <label class="form-label">URL</label>
                                <input type="url" class="form-control" placeholder="https://">
                            </div>
                        </div>
                    </div>
                </div>
            `;

            carouselCards.insertAdjacentHTML('beforeend', cardHtml);

            // Add remove handler
            const newCard = carouselCards.lastElementChild;
            newCard.querySelector('.btn-close').addEventListener('click', () => {
                newCard.remove();
                updateFormState();
            });

            updateFormState();
        });
    }

    // Listen for platform changes
    document.querySelectorAll('.platform-option input').forEach(input => {
        input.addEventListener('change', () => {
            updateCharacterLimits();
            updateCTAOptions();
        });
    });

    // Initialize
    updateCharacterLimits();
    updateCTAOptions();
} 
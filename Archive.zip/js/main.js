const translations = {
    en: {
        hero_title: "Cut Your Electricity Bills with Solar Energy",
        hero_subtitle: "Professional solar solutions for a sustainable future",
        calculate_savings: "Calculate Your Savings",
        learn_more: "Learn More",
        get_consultation: "Get Free Consultation",
        your_name: "Your Name",
        phone_number: "Phone Number",
        select_area: "Select Your Area",
        monthly_bill: "Monthly Bill (PKR)",
        get_quote: "Get Free Quote Now",
        secure_info: "Your information is secure with us",
        services_title: "Solar Solutions for Karachi's Climate",
        load_shedding: "Load Shedding Solution",
        dust_proof: "Dust-Proof Systems",
        easy_financing: "Easy Financing",
        features_title: "Why Choose Our Solar Solutions?",
        perfect_sun: "Perfect for Karachi's Sun",
        sunny_days: "Optimized for 300+ sunny days",
        save_bills: "Save on KE Bills",
        bill_reduction: "Up to 70% reduction in bills",
        local_support: "Local Support Team",
        quick_service: "Quick service in your area",
        warranty: "10 Year Warranty",
        peace_mind: "Long-term peace of mind",
        contact_us: "Contact Us",
        quick_links: "Quick Links",
        follow_us: "Follow Us",
        about_us: "About Us",
        contact: "Contact",
        thank_you: "Thank You!",
        contact_soon: "We'll contact you within 24 hours",
        processing: "Processing...",
        error_message: "There was an error. Please try again.",
        annual_savings: "Annual Savings",
        monthly_savings: "Monthly Savings",
        payback_period: "Investment Payback Period",
        years: "Years",
        get_detailed: "Get Detailed Quote",
        detailed_analysis: "Get detailed analysis and customized solution for your home in",
        solar_solutions_title: "Solar Solutions for Karachi's Climate",
        load_shedding_title: "Load Shedding Solution",
        load_shedding_desc: "Say goodbye to power outages with our complete solar backup solutions, perfect for Karachi's electricity challenges.",
        power_supply: "24/7 Power Supply",
        zero_loadshedding: "Zero Load Shedding",
        reduced_bills: "Reduced K-Electric Bills",
        dust_proof_title: "Dust-Proof Systems",
        dust_proof_desc: "Specially designed systems to handle Karachi's dusty environment with regular maintenance services.",
        dust_resistant: "Dust-Resistant Panels",
        monthly_cleaning: "Monthly Cleaning Service",
        tech_support: "24/7 Technical Support",
        financing_title: "Easy Financing",
        financing_desc: "Affordable payment plans with leading banks in Karachi. Convert your electricity expense into an investment.",
        islamic_financing: "Islamic Financing Available",
        monthly_installments: "Easy Monthly Installments",
        bank_leasing: "Bank Leasing Options",
        area_dha: "DHA (All Phases)",
        area_clifton: "Clifton",
        area_gulshan: "Gulshan-e-Iqbal",
        area_nazimabad: "Nazimabad",
        area_defence: "Defence",
        area_pechs: "PECHS",
        area_north: "North Karachi",
        area_other: "Other Areas",
        whatsapp_cta: "Chat on WhatsApp",
        whatsapp_button: "Get Free Quote on WhatsApp",
        whatsapp_greeting: "Hello! I'm interested in solar installation.",
        whatsapp_area: "Area",
        whatsapp_bill: "Monthly Bill: PKR"
    },
    ur: {
        hero_title: "بجلی کے بل میں کمی کریں سولر انرجی کے ساتھ",
        hero_subtitle: "کراچی کے لیے مکمل سولر سسٹم",
        calculate_savings: "اپنی بچت کا حساب لگائیں",
        learn_more: "مزید معلومات",
        get_consultation: "مفت مشورہ حاصل کریں",
        your_name: "آپکا نام",
        phone_number: "موبائل نمبر",
        select_area: "علاقہ منتخب کریں",
        monthly_bill: "موجودہ بجلی کا بل",
        get_quote: "قیمت معلوم کریں",
        secure_info: "آپ کی معلومات محفوظ ہیں",
        services_title: "کراچی کی موسم کے مطابق سولر سسٹم",
        load_shedding: "لوڈشیڈنگ کا مکمل حل",
        dust_proof: "دھول سے محفوظ سسٹم",
        easy_financing: "آسان قسطوں کی سہولت",
        features_title: "ہمارا سولر سسٹم کیوں چنیں؟",
        perfect_sun: "کراچی کی دھوپ کے لیے بہترین",
        sunny_days: "300+ دن دھوپ کے لیے موزوں",
        save_bills: "بجلی کے بل میں بچت",
        bill_reduction: "70% تک بل میں کمی",
        local_support: "مقامی سروس ٹیم",
        quick_service: "فوری سروس آپکے علاقے میں",
        warranty: "10 سال وارنٹی",
        peace_mind: "پوری تسلی کے ساتھ",
        contact_us: "رابطہ کریں",
        quick_links: "فوری لنکس",
        follow_us: "سوشل میڈیا",
        about_us: "ہمارے بارے میں",
        contact: "رابطہ",
        thank_you: "شکریہ!",
        contact_soon: "ہم 24 گھنٹے کے اندر آپ سے رابطہ کریں گے",
        processing: "درخواست بھیج رہے ہیں...",
        error_message: "معذرت، دوبارہ کوشش کریں",
        annual_savings: "سالانہ بچت",
        monthly_savings: "ماہانہ بچت",
        payback_period: "ادائیگی کا عرصہ",
        years: "سال",
        get_detailed: "مکمل تفصیلات حاصل کریں",
        detailed_analysis: "اپنے علاقے کے لیے مکمل تجزیہ حاصل کریں",
        solar_solutions_title: "کراچی کی موسم کے مطابق سولر سسٹم",
        load_shedding_title: "لوڈشیڈنگ کا مکمل حل",
        load_shedding_desc: "بجلی کی بندش سے نجات - کراچی کے لیے خاص سولر بیک اپ سسٹم",
        power_supply: "24 گھنٹے بجلی",
        zero_loadshedding: "لوڈشیڈنگ سے آزادی",
        reduced_bills: "کے ای بل میں کمی",
        dust_proof_title: "دھول سے محفوظ سسٹم",
        dust_proof_desc: "کراچی کی گرد و غبار کے لیے خاص ڈیزائن کردہ سسٹم، باقاعدہ صفائی کی سہولت کے ساتھ",
        dust_resistant: "دھول سے محفوظ پینل",
        monthly_cleaning: "ہر ماہ صفائی کی سروس",
        tech_support: "24 گھنٹے ٹیکنیکل سپورٹ",
        financing_title: "آسان قسطوں کی سہولت",
        financing_desc: "کراچی کے بینکوں کے ساتھ آسان ماہانہ قسطوں کی سہولت",
        islamic_financing: "اسلامی فنانسنگ موجود ہے",
        monthly_installments: "آسان ماہانہ قسطیں",
        bank_leasing: "بینک لیزنگ دستیاب",
        area_dha: "ڈی ایچ اے (تمام فیز)",
        area_clifton: "کلفٹن",
        area_gulshan: "گلشنِ اقبال",
        area_nazimabad: "ناظم آباد",
        area_defence: "ڈیفنس",
        area_pechs: "پی ای سی ایچ ایس",
        area_north: "نارتھ کراچی",
        area_other: "دیگر علاقے",
        whatsapp_cta: "واٹس ایپ پر رابطہ کریں",
        whatsapp_button: "واٹس ایپ پر مفت قیمت حاصل کریں",
        whatsapp_greeting: "السلام علیکم! مجھے سولر انسٹالیش میں دلچسپی ہے۔",
        whatsapp_area: "علاقہ",
        whatsapp_bill: "ماہانہ بل: روپے"
    }
};

// Solar calculator constants
const SOLAR_CONSTANTS = {
    packages: {
        basic: {
            name: "Basic Home Package",
            capacity: 3, // kW
            supports: {
                fans: 6,
                lights: 8,
                tv: 1,
                fridge: 1,
                other: "Small appliances"
            },
            cost: 450000,
            backupHours: 4
        },
        comfort: {
            name: "Comfort Package",
            capacity: 5, // kW
            supports: {
                fans: 8,
                lights: 12,
                tv: 2,
                fridge: 1,
                ac: "1 ton AC (8 hours)",
                other: "Medium appliances"
            },
            cost: 750000,
            backupHours: 6
        },
        premium: {
            name: "Premium Package",
            capacity: 10, // kW
            supports: {
                fans: 12,
                lights: 15,
                tv: 3,
                fridge: 2,
                ac: "2 ton AC (12 hours)",
                other: "All home appliances"
            },
            cost: 1500000,
            backupHours: 8
        }
    },
    appliances: {
        fan: { watts: 80, defaultHours: 16, label: "Fans" },
        light: { watts: 20, defaultHours: 8, label: "LED Lights" },
        tv: { watts: 100, defaultHours: 8, label: "TV" },
        fridge: { watts: 200, defaultHours: 24, label: "Refrigerator" },
        ac1ton: { watts: 1200, defaultHours: 8, label: "1 Ton AC" },
        ac2ton: { watts: 2400, defaultHours: 8, label: "2 Ton AC" },
        microwave: { watts: 800, defaultHours: 1, label: "Microwave" },
        washingMachine: { watts: 500, defaultHours: 2, label: "Washing Machine" },
        waterPump: { watts: 750, defaultHours: 2, label: "Water Pump" }
    },
    solarConstants: {
        peakSunHours: 5.5, // Karachi average
        panelEfficiency: 0.185, // 18.5% efficiency
        systemLosses: 0.14, // 14% system losses
        panelCostPerWatt: 85, // PKR per watt
        batteryCostPerKwh: 13500, // PKR per kWh
        inverterCostPerKva: 15000, // PKR per kVA
        installationCostPercent: 0.12 // 12% of system cost
    }
};

document.addEventListener('DOMContentLoaded', () => {
    // Initialize Bootstrap tooltips
    const tooltipTriggerList = [].slice.call(document.querySelectorAll('[data-bs-toggle="tooltip"]'));
    tooltipTriggerList.map(function (tooltipTriggerEl) {
        return new bootstrap.Tooltip(tooltipTriggerEl);
    });

    // Solar savings calculator
    const calculatorForm = document.getElementById('savings-form');
    if (calculatorForm) {
        calculatorForm.addEventListener('submit', (e) => {
            e.preventDefault();
            calculateSavings();
        });
    }

    // Contact form handling
    const contactForm = document.getElementById('contact-form');
    if (contactForm) {
        contactForm.addEventListener('submit', async (e) => {
            e.preventDefault();
            await handleContactSubmission();
        });
    }

    // Smooth scroll for anchor links
    document.querySelectorAll('a[href^="#"]').forEach(anchor => {
        anchor.addEventListener('click', function (e) {
            e.preventDefault();
            const target = document.querySelector(this.getAttribute('href'));
            if (target) {
                const headerOffset = 80;
                const elementPosition = target.getBoundingClientRect().top;
                const offsetPosition = elementPosition + window.pageYOffset - headerOffset;

                window.scrollTo({
                    top: offsetPosition,
                    behavior: 'smooth'
                });
            }
        });
    });

    // Quick contact form handling
    const quickContactForm = document.getElementById('quick-contact-form');
    if (quickContactForm) {
        quickContactForm.addEventListener('submit', async (e) => {
            e.preventDefault();
            
            // Custom validation
            const nameInput = quickContactForm.querySelector('input[type="text"]');
            const phoneInput = quickContactForm.querySelector('input[type="tel"]');
            
            // Name validation
            if (!/^[A-Za-z\s]{3,50}$/.test(nameInput.value)) {
                nameInput.setCustomValidity('Please enter a valid name (3-50 characters)');
                nameInput.reportValidity();
                return;
            }
            
            // Phone validation
            if (!/^[0-9]{11}$/.test(phoneInput.value)) {
                phoneInput.setCustomValidity('Please enter a valid 11-digit phone number');
                phoneInput.reportValidity();
                return;
            }

            const submitBtn = quickContactForm.querySelector('button[type="submit"]');
            submitBtn.disabled = true;
            submitBtn.innerHTML = `
                <span class="spinner-border spinner-border-sm me-2"></span>
                ${translations[document.documentElement.dir === 'rtl' ? 'ur' : 'en'].processing}
            `;

            try {
                // Simulate form submission
                await new Promise(resolve => setTimeout(resolve, 1000));
                
                // Show success message
                quickContactForm.innerHTML = `
                    <div class="text-center py-4">
                        <i class="bi bi-check-circle text-success display-1"></i>
                        <h4 class="mt-3 text-dark">${translations[document.documentElement.dir === 'rtl' ? 'ur' : 'en'].thank_you}</h4>
                        <p class="text-muted">${translations[document.documentElement.dir === 'rtl' ? 'ur' : 'en'].contact_soon}</p>
                    </div>
                `;
            } catch (error) {
                console.error('Error:', error);
                submitBtn.disabled = false;
                submitBtn.textContent = translations[document.documentElement.dir === 'rtl' ? 'ur' : 'en'].get_quote;
                
                const errorDiv = document.createElement('div');
                errorDiv.className = 'alert alert-danger mt-3';
                errorDiv.textContent = translations[document.documentElement.dir === 'rtl' ? 'ur' : 'en'].error_message;
                quickContactForm.insertBefore(errorDiv, submitBtn);
            }
        });

        // Clear custom validity on input
        quickContactForm.querySelectorAll('input').forEach(input => {
            input.addEventListener('input', () => {
                input.setCustomValidity('');
            });
        });
    }

    // Language switching
    const languageSelector = document.querySelector('.language-selector');
    if (languageSelector) {
        languageSelector.addEventListener('change', (e) => {
            const language = e.target.value;
            updateLanguage(language);
        });
    }

    // Initialize area dropdowns
    const areaDropdowns = document.querySelectorAll('.area-dropdown');
    
    areaDropdowns.forEach(dropdown => {
        const toggle = dropdown.querySelector('.dropdown-toggle');
        const selectedOption = dropdown.querySelector('.selected-option');
        const items = dropdown.querySelectorAll('.dropdown-item');
        const placeholder = selectedOption.dataset.placeholder;
        
        // Initialize Bootstrap dropdown
        new bootstrap.Dropdown(toggle);
        
        // Create hidden input
        const hiddenInput = document.createElement('input');
        hiddenInput.type = 'hidden';
        hiddenInput.name = 'area';
        dropdown.appendChild(hiddenInput);

        items.forEach(item => {
            item.addEventListener('click', (e) => {
                e.preventDefault();
                e.stopPropagation();
                
                const value = item.dataset.value;
                const text = item.textContent.trim();
                
                // Update selected text and value
                selectedOption.textContent = text;
                hiddenInput.value = value;
                
                // Update active state
                items.forEach(i => i.classList.remove('active'));
                item.classList.add('active');

                // Close dropdown
                const bsDropdown = bootstrap.Dropdown.getInstance(toggle);
                if (bsDropdown) {
                    bsDropdown.hide();
                }
            });
        });

        // Reset placeholder when dropdown is hidden and no selection
        toggle.addEventListener('hidden.bs.dropdown', () => {
            if (!hiddenInput.value && placeholder) {
                selectedOption.textContent = translations[document.documentElement.dir === 'rtl' ? 'ur' : 'en'].select_area;
            }
        });
    });

    // Language dropdown handling
    const languageDropdown = document.querySelector('.language-dropdown');
    if (languageDropdown) {
        const languageItems = languageDropdown.querySelectorAll('.dropdown-item');
        const selectedOption = languageDropdown.querySelector('.selected-option');

        languageItems.forEach(item => {
            item.addEventListener('click', (e) => {
                e.preventDefault();
                e.stopPropagation();
                
                const language = item.dataset.value;
                const text = item.textContent.trim();

                // Update selected text
                selectedOption.textContent = text;
                selectedOption.dataset.value = language;

                // Update language
                updateLanguage(language);

                // Close dropdown
                const dropdownToggle = languageDropdown.querySelector('.dropdown-toggle');
                const bsDropdown = bootstrap.Dropdown.getInstance(dropdownToggle);
                if (bsDropdown) {
                    bsDropdown.hide();
                }
            });
        });
    }

    // Initialize the calculator
    initializeCalculator();

    // Initialize calculator in simple mode by default
    toggleCalculatorMode('simple');
});

function updateLanguage(language) {
    // Update text content for elements with data-lang attributes
    document.querySelectorAll('[data-lang-' + language + ']').forEach(element => {
        element.textContent = element.getAttribute('data-lang-' + language);
    });

    // Update other text content using translations object
    Object.keys(translations[language]).forEach(key => {
        const elements = document.querySelectorAll(`[data-translate="${key}"]`);
        elements.forEach(element => {
            element.textContent = translations[language][key];
        });
    });

    // Update all form elements and placeholders based on language
    if (language === 'ur') {
        document.documentElement.setAttribute('dir', 'rtl');
        document.body.classList.add('urdu');
        
        // Update quick contact form
        updateFormElements({
            '#quick-contact-form input[type="text"]': translations.ur.your_name,
            '#quick-contact-form input[type="tel"]': translations.ur.phone_number,
            '#quick-contact-form input[type="number"]': translations.ur.monthly_bill,
            '#quick-contact-form .selected-option': translations.ur.select_area,
            '#quick-contact-form button[type="submit"]': translations.ur.get_quote,
            '#quick-contact-form .small': translations.ur.secure_info
        });

        // Update calculator form
        updateFormElements({
            '#savings-form label:first-child': translations.ur.monthly_bill,
            '#savings-form label:last-child': translations.ur.select_area,
            '#savings-form button': translations.ur.calculate_savings
        });

        // Update contact form
        updateFormElements({
            '#contact-form label[for="name"]': translations.ur.your_name,
            '#contact-form label[for="email"]': translations.ur.email,
            '#contact-form label[for="phone"]': translations.ur.phone_number,
            '#contact-form label[for="message"]': translations.ur.message,
            '#contact-form button': translations.ur.send_message
        });

    } else {
        document.documentElement.setAttribute('dir', 'ltr');
        document.body.classList.remove('urdu');
        
        // Update quick contact form
        updateFormElements({
            '#quick-contact-form input[type="text"]': translations.en.your_name,
            '#quick-contact-form input[type="tel"]': translations.en.phone_number,
            '#quick-contact-form input[type="number"]': translations.en.monthly_bill,
            '#quick-contact-form .selected-option': translations.en.select_area,
            '#quick-contact-form button[type="submit"]': translations.en.get_quote,
            '#quick-contact-form .small': translations.en.secure_info
        });

        // Update calculator form
        updateFormElements({
            '#savings-form label:first-child': translations.en.monthly_bill,
            '#savings-form label:last-child': translations.en.select_area,
            '#savings-form button': translations.en.calculate_savings
        });

        // Update contact form
        updateFormElements({
            '#contact-form label[for="name"]': translations.en.your_name,
            '#contact-form label[for="email"]': translations.en.email,
            '#contact-form label[for="phone"]': translations.en.phone_number,
            '#contact-form label[for="message"]': translations.en.message,
            '#contact-form button': translations.en.send_message
        });
    }

    // Update dropdowns
    updateDropdowns(language);

    // Update area dropdown specifically
    const areaDropdowns = document.querySelectorAll('.area-dropdown');
    areaDropdowns.forEach(dropdown => {
        const selectedOption = dropdown.querySelector('.selected-option');
        const placeholder = selectedOption.dataset.placeholder;
        if (!selectedOption.dataset.value) {  // Only update if no area is selected
            selectedOption.textContent = translations[language].select_area;
        }
        
        // Update dropdown items
        dropdown.querySelectorAll('.dropdown-item').forEach(item => {
            const areaKey = `area_${item.dataset.value}`;
            if (translations[language][areaKey]) {
                item.textContent = translations[language][areaKey];
            }
        });
    });
}

function updateFormElements(mappings) {
    Object.entries(mappings).forEach(([selector, value]) => {
        const elements = document.querySelectorAll(selector);
        elements.forEach(element => {
            if (element.tagName.toLowerCase() === 'input') {
                element.placeholder = value;
            } else {
                element.textContent = value;
            }
        });
    });
}

function updateDropdowns(language) {
    // Update area dropdown items
    document.querySelectorAll('.area-dropdown .dropdown-item').forEach(item => {
        const key = item.dataset.value;
        const areaKey = `area_${key}`;
        if (translations[language][areaKey]) {
            item.textContent = translations[language][areaKey];
        }
    });

    // Reset dropdown placeholders
    document.querySelectorAll('.dropdown .selected-option').forEach(option => {
        const placeholder = option.dataset.placeholder;
        if (placeholder) {
            option.textContent = translations[language][placeholder.toLowerCase()] || placeholder;
        }
    });
}

// Update the calculator function
function calculateSavings() {
    const monthlyBill = parseFloat(document.getElementById('monthly-bill').value);
    const loadShedding = parseInt(document.getElementById('loadshedding').value);
    
    // Get selected appliances
    const fans = document.querySelector('#fans').checked ? 
        parseInt(document.querySelector('#fans').closest('.form-check').querySelector('select').value) : 0;
    const hasAC = document.querySelector('#ac').checked;
    const acTons = hasAC ? 
        parseFloat(document.querySelector('#ac').closest('.form-check').querySelector('select').value) : 0;
    const hasFridge = document.querySelector('#fridge').checked;
    const hasTV = document.querySelector('#tv').checked;

    // Determine recommended package based on requirements
    let recommendedPackage;
    if (acTons >= 2 || fans > 8) {
        recommendedPackage = 'premium';
    } else if (acTons >= 1 || fans > 6) {
        recommendedPackage = 'comfort';
    } else {
        recommendedPackage = 'basic';
    }

    const package = SOLAR_CONSTANTS.packages[recommendedPackage];
    
    // Calculate monthly savings
    const monthlySavings = calculateMonthlySavings(monthlyBill);
    const paybackPeriod = package.cost / (monthlySavings * 12);

    displayResults({
        recommendedPackage,
        monthlySavings,
        paybackPeriod
    });
}

function calculateMonthlySavings(currentBill) {
    // Simplified calculation: assume 60% reduction in bill
    return currentBill * 0.6;
}

// Add this function to initialize the calculator
function initializeCalculator() {
    const calculatorForm = document.getElementById('savings-form');
    if (calculatorForm) {
        calculatorForm.innerHTML = `
            <div class="mb-4">
                <label class="form-label">What do you want to power with solar?</label>
                <div class="appliance-selector">
                    <div class="row g-3">
                        <div class="col-md-6">
                            <div class="form-check custom-checkbox">
                                <input class="form-check-input" type="checkbox" id="fans" checked>
                                <label class="form-check-label" for="fans">
                                    <i class="bi bi-fan"></i> Fans
                                    <select class="form-select form-select-sm d-inline-block w-auto ms-2">
                                        <option value="4">4</option>
                                        <option value="6" selected>6</option>
                                        <option value="8">8</option>
                                        <option value="10">10+</option>
                                    </select>
                                </label>
                            </div>
                        </div>
                        <div class="col-md-6">
                            <div class="form-check custom-checkbox">
                                <input class="form-check-input" type="checkbox" id="ac" checked>
                                <label class="form-check-label" for="ac">
                                    <i class="bi bi-thermometer-half"></i> AC
                                    <select class="form-select form-select-sm d-inline-block w-auto ms-2">
                                        <option value="1">1 ton</option>
                                        <option value="1.5">1.5 ton</option>
                                        <option value="2">2 ton</option>
                                    </select>
                                </label>
                            </div>
                        </div>
                        <div class="col-md-6">
                            <div class="form-check custom-checkbox">
                                <input class="form-check-input" type="checkbox" id="fridge" checked>
                                <label class="form-check-label" for="fridge">
                                    <i class="bi bi-snow"></i> Refrigerator
                                </label>
                            </div>
                        </div>
                        <div class="col-md-6">
                            <div class="form-check custom-checkbox">
                                <input class="form-check-input" type="checkbox" id="tv" checked>
                                <label class="form-check-label" for="tv">
                                    <i class="bi bi-tv"></i> TV/Electronics
                                </label>
                            </div>
                        </div>
                    </div>
                </div>
            </div>

            <div class="mb-4">
                <label class="form-label">Current Monthly K-Electric Bill</label>
                <div class="input-group">
                    <span class="input-group-text">PKR</span>
                    <input type="number" class="form-control" id="monthly-bill" required min="1000" max="500000" step="100">
                </div>
            </div>

            <div class="mb-4">
                <label class="form-label">Daily Load Shedding Duration</label>
                <select class="form-select" id="loadshedding" required>
                    <option value="2">Up to 2 hours</option>
                    <option value="4" selected>2-4 hours</option>
                    <option value="6">4-6 hours</option>
                    <option value="8">6+ hours</option>
                </select>
            </div>

            <button type="submit" class="btn btn-primary w-100 btn-lg">
                Show Recommended Package
            </button>
        `;

        calculatorForm.addEventListener('submit', (e) => {
            e.preventDefault();
            calculateSavings();
        });
    }
}

function displayResults(data) {
    const resultsDiv = document.getElementById('results');
    const package = SOLAR_CONSTANTS.packages[data.recommendedPackage];
    
    resultsDiv.innerHTML = `
        <div class="results-container">
            <div class="recommended-package mb-4">
                <div class="card border-0 bg-primary text-white">
                    <div class="card-body">
                        <h4 class="card-title">Recommended Package</h4>
                        <h3 class="display-6 mb-3">${package.name}</h3>
                        <div class="package-details">
                            <div class="row g-3">
                                <div class="col-md-6">
                                    <strong>System Size:</strong> ${package.capacity} kW
                                </div>
                                <div class="col-md-6">
                                    <strong>Backup Time:</strong> ${package.backupHours} hours
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>

            <div class="package-features mb-4">
                <h5>This Package Supports:</h5>
                <div class="row g-3">
                    <div class="col-md-6">
                        <div class="feature-item">
                            <i class="bi bi-fan"></i>
                            <span>Up to ${package.supports.fans} Fans</span>
                        </div>
                    </div>
                    <div class="col-md-6">
                        <div class="feature-item">
                            <i class="bi bi-lightbulb"></i>
                            <span>${package.supports.lights} Lights</span>
                        </div>
                    </div>
                    <div class="col-md-6">
                        <div class="feature-item">
                            <i class="bi bi-thermometer-half"></i>
                            <span>${package.supports.ac}</span>
                        </div>
                    </div>
                    <div class="col-md-6">
                        <div class="feature-item">
                            <i class="bi bi-snow"></i>
                            <span>${package.supports.fridge} Refrigerator</span>
                        </div>
                    </div>
                </div>
            </div>

            <div class="financial-summary mb-4">
                <div class="row g-3">
                    <div class="col-md-4">
                        <div class="card h-100 border-0 bg-light">
                            <div class="card-body text-center">
                                <h5 class="card-title">System Cost</h5>
                                <p class="display-6 mb-0">PKR ${package.cost.toLocaleString()}</p>
                                <small class="text-muted">Easy installments available</small>
                            </div>
                        </div>
                    </div>
                    <div class="col-md-4">
                        <div class="card h-100 border-0 bg-light">
                            <div class="card-body text-center">
                                <h5 class="card-title">Monthly Savings</h5>
                                <p class="display-6 mb-0">PKR ${Math.round(data.monthlySavings).toLocaleString()}</p>
                                <small class="text-muted">On K-Electric bill</small>
                            </div>
                        </div>
                    </div>
                    <div class="col-md-4">
                        <div class="card h-100 border-0 bg-light">
                            <div class="card-body text-center">
                                <h5 class="card-title">Recovery Period</h5>
                                <p class="display-6 mb-0">${data.paybackPeriod.toFixed(1)} Years</p>
                                <small class="text-muted">Investment payback time</small>
                            </div>
                        </div>
                    </div>
                </div>
            </div>

            <div class="text-center">
                <button onclick="openWhatsApp()" class="btn btn-lg btn-success">
                    <i class="bi bi-whatsapp me-2"></i>
                    Get Detailed Quote on WhatsApp
                </button>
            </div>
        </div>
    `;
}

// Contact form submission
const handleContactSubmission = async () => {
    const submitButton = document.querySelector('#contact-form button[type="submit"]');
    submitButton.disabled = true;
    submitButton.innerHTML = '<span class="spinner-border spinner-border-sm me-2"></span>Sending...';

    try {
        // Add your form submission logic here
        await new Promise(resolve => setTimeout(resolve, 1000)); // Simulated delay
        
        // Show success message
        const form = document.getElementById('contact-form');
        form.innerHTML = `
            <div class="alert alert-success mb-0">
                <h4 class="alert-heading">Thank You!</h4>
                <p class="mb-0">We've received your message and will contact you soon.</p>
            </div>
        `;
    } catch (error) {
        console.error('Error submitting form:', error);
        // Show error message
        const errorDiv = document.createElement('div');
        errorDiv.className = 'alert alert-danger mt-3';
        errorDiv.textContent = 'There was an error submitting the form. Please try again.';
        form.appendChild(errorDiv);
        
        submitButton.disabled = false;
        submitButton.textContent = 'Send Message';
    }
};

// Add this function to handle WhatsApp integration
function openWhatsApp(formData = null) {
    const phone = "16313048422";
    let message = "";

    if (formData) {
        // Create message from form data
        message = `Hello! I'm interested in solar installation.\n\n`;
        message += `Name: ${formData.name}\n`;
        message += `Phone: ${formData.phone}\n`;
        if (formData.area) message += `Area: ${formData.area}\n`;
        if (formData.bill) message += `Monthly Bill: PKR ${formData.bill}\n`;
    } else {
        // Default message
        message = "Hello! I'm interested in getting a quote for solar installation.";
    }

    // Encode the message for URL
    const encodedMessage = encodeURIComponent(message);
    const whatsappUrl = `https://wa.me/${phone}?text=${encodedMessage}`;
    window.open(whatsappUrl, '_blank');
}

// Update the quick contact form submission
const quickContactForm = document.getElementById('quick-contact-form');
if (quickContactForm) {
    quickContactForm.addEventListener('submit', async (e) => {
        e.preventDefault();
        
        // Form validation...

        // Collect form data
        const formData = {
            name: quickContactForm.querySelector('input[type="text"]').value,
            phone: quickContactForm.querySelector('input[type="tel"]').value,
            area: quickContactForm.querySelector('input[name="area"]')?.value,
            bill: quickContactForm.querySelector('input[type="number"]').value
        };

        // Open WhatsApp with form data
        openWhatsApp(formData);
    });
}

// Add mode toggle function
function toggleCalculatorMode(mode) {
    const calculatorForm = document.getElementById('savings-form');
    if (mode === 'simple') {
        calculatorForm.innerHTML = `
            <div class="calculator-mode-toggle mb-4">
                <div class="btn-group w-100" role="group">
                    <button type="button" class="btn btn-primary active" onclick="toggleCalculatorMode('simple')">Simple Mode</button>
                    <button type="button" class="btn btn-outline-primary" onclick="toggleCalculatorMode('advanced')">Advanced Mode</button>
                </div>
            </div>

            <div class="mb-4">
                <label class="form-label">What's your typical monthly bill?</label>
                <div class="bill-range">
                    <div class="form-check">
                        <input class="form-check-input" type="radio" name="billRange" id="range1" value="small">
                        <label class="form-check-label" for="range1">
                            <strong>Small Home</strong>
                            <span class="d-block text-muted">PKR 5,000 - 15,000</span>
                        </label>
                    </div>
                    <div class="form-check">
                        <input class="form-check-input" type="radio" name="billRange" id="range2" value="medium" checked>
                        <label class="form-check-label" for="range2">
                            <strong>Medium Home</strong>
                            <span class="d-block text-muted">PKR 15,000 - 30,000</span>
                        </label>
                    </div>
                    <div class="form-check">
                        <input class="form-check-input" type="radio" name="billRange" id="range3" value="large">
                        <label class="form-check-label" for="range3">
                            <strong>Large Home</strong>
                            <span class="d-block text-muted">PKR 30,000+</span>
                        </label>
                    </div>
                </div>
            </div>

            <div class="mb-4">
                <label class="form-label">Do you use AC?</label>
                <div class="ac-usage">
                    <div class="form-check">
                        <input class="form-check-input" type="radio" name="acUsage" id="noAc" value="none">
                        <label class="form-check-label" for="noAc">No AC</label>
                    </div>
                    <div class="form-check">
                        <input class="form-check-input" type="radio" name="acUsage" id="lightAc" value="light" checked>
                        <label class="form-check-label" for="lightAc">1-2 AC Units</label>
                    </div>
                    <div class="form-check">
                        <input class="form-check-input" type="radio" name="acUsage" id="heavyAc" value="heavy">
                        <label class="form-check-label" for="heavyAc">3+ AC Units</label>
                    </div>
                </div>
            </div>

            <button type="submit" class="btn btn-primary w-100 btn-lg">
                Show Recommended Package
            </button>
        `;
    } else {
        // Advanced mode - keep your existing detailed form
        initializeAdvancedCalculator();
    }

    // Reattach submit event listener
    calculatorForm.addEventListener('submit', (e) => {
        e.preventDefault();
        if (mode === 'simple') {
            calculateSimpleSavings();
        } else {
            calculateSavings();
        }
    });
}

// Add simple calculation function
function calculateSimpleSavings() {
    const billRange = document.querySelector('input[name="billRange"]:checked').value;
    const acUsage = document.querySelector('input[name="acUsage"]:checked').value;

    let recommendedPackage;
    
    // Simple logic for package recommendation
    if (billRange === 'large' || acUsage === 'heavy') {
        recommendedPackage = 'premium';
    } else if (billRange === 'medium' || acUsage === 'light') {
        recommendedPackage = 'comfort';
    } else {
        recommendedPackage = 'basic';
    }

    const package = SOLAR_CONSTANTS.packages[recommendedPackage];
    
    // Estimate monthly savings based on bill range
    const averageBills = {
        small: 10000,
        medium: 22500,
        large: 40000
    };
    
    const monthlySavings = calculateMonthlySavings(averageBills[billRange]);
    const paybackPeriod = package.cost / (monthlySavings * 12);

    displayResults({
        recommendedPackage,
        monthlySavings,
        paybackPeriod
    });
}

function initializeAdvancedCalculator() {
    const calculatorForm = document.getElementById('savings-form');
    if (calculatorForm) {
        calculatorForm.innerHTML = `
            <div class="calculator-mode-toggle mb-4">
                <div class="btn-group w-100" role="group">
                    <button type="button" class="btn btn-outline-primary" onclick="toggleCalculatorMode('simple')">Simple Mode</button>
                    <button type="button" class="btn btn-primary active" onclick="toggleCalculatorMode('advanced')">Advanced Mode</button>
                </div>
            </div>

            <div class="mb-4">
                <h5 class="mb-3">Select Your Appliances</h5>
                <div class="appliance-selector advanced">
                    <div class="row g-3" id="applianceList">
                        ${generateApplianceInputs()}
                    </div>
                </div>
            </div>

            <div class="mb-4">
                <h5 class="mb-3">Load Shedding & Backup</h5>
                <div class="row g-3">
                    <div class="col-md-6">
                        <label class="form-label">Daily Load Shedding Hours</label>
                        <select class="form-select" id="loadShedding" required>
                            <option value="2">Up to 2 hours</option>
                            <option value="4" selected>2-4 hours</option>
                            <option value="6">4-6 hours</option>
                            <option value="8">6+ hours</option>
                        </select>
                    </div>
                    <div class="col-md-6">
                        <label class="form-label">Desired Backup Duration</label>
                        <select class="form-select" id="backupHours" required>
                            <option value="4">4 hours</option>
                            <option value="6" selected>6 hours</option>
                            <option value="8">8 hours</option>
                            <option value="12">12 hours</option>
                        </select>
                    </div>
                </div>
            </div>

            <div class="mb-4">
                <h5 class="mb-3">Current Electricity Usage</h5>
                <div class="row g-3">
                    <div class="col-md-6">
                        <label class="form-label">Monthly Bill (PKR)</label>
                        <input type="number" class="form-control" id="monthlyBill" required min="1000" max="500000" step="100">
                    </div>
                    <div class="col-md-6">
                        <label class="form-label">Connection Type</label>
                        <select class="form-select" id="connectionType">
                            <option value="residential">Residential</option>
                            <option value="commercial">Commercial</option>
                        </select>
                    </div>
                </div>
            </div>

            <button type="submit" class="btn btn-primary w-100 btn-lg">
                Calculate Detailed Solution
            </button>
        `;

        // Initialize form event listeners
        initializeAdvancedFormHandlers();
    }
}

function generateApplianceInputs() {
    return Object.entries(SOLAR_CONSTANTS.appliances).map(([key, appliance]) => `
        <div class="col-md-6">
            <div class="appliance-card">
                <div class="form-check d-flex align-items-center justify-content-between">
                    <div class="d-flex align-items-center gap-2">
                        <input class="form-check-input appliance-checkbox" type="checkbox" id="${key}" data-appliance="${key}">
                        <label class="form-check-label" for="${key}">
                            <i class="bi bi-${getApplianceIcon(key)}"></i>
                            ${appliance.label}
                        </label>
                    </div>
                    <button type="button" class="btn btn-link btn-sm text-primary settings-toggle" style="display: none;">
                        <i class="bi bi-gear"></i>
                    </button>
                </div>
                <div class="appliance-details mt-2" style="display: none;">
                    <div class="usage-sliders">
                        <div class="mb-2">
                            <div class="d-flex justify-content-between align-items-center">
                                <small class="text-muted">Quantity: <span class="quantity-value">1</span></small>
                                <div class="btn-group btn-group-sm">
                                    <button type="button" class="btn btn-outline-secondary qty-adjust" data-action="decrease">-</button>
                                    <button type="button" class="btn btn-outline-secondary qty-adjust" data-action="increase">+</button>
                                </div>
                            </div>
                            <input type="range" class="form-range quantity-range" min="1" max="10" value="1">
                        </div>
                        <div>
                            <div class="d-flex justify-content-between align-items-center">
                                <small class="text-muted">Hours: <span class="hours-value">${appliance.defaultHours}</span></small>
                                <div class="usage-presets btn-group btn-group-sm">
                                    <button type="button" class="btn btn-outline-secondary" data-hours="4">Low</button>
                                    <button type="button" class="btn btn-outline-secondary" data-hours="8">Med</button>
                                    <button type="button" class="btn btn-outline-secondary" data-hours="12">High</button>
                                </div>
                            </div>
                            <input type="range" class="form-range hours-range" min="1" max="24" value="${appliance.defaultHours}">
                        </div>
                    </div>
                </div>
            </div>
        </div>
    `).join('');
}

function getApplianceIcon(applianceKey) {
    const icons = {
        fan: 'fan',
        light: 'lightbulb',
        tv: 'tv',
        fridge: 'snow',
        ac1ton: 'thermometer-half',
        ac2ton: 'thermometer-high',
        microwave: 'broadcast',
        washingMachine: 'water',
        waterPump: 'droplet'
    };
    return icons[applianceKey] || 'plug';
}

function initializeAdvancedFormHandlers() {
    // Handle appliance checkboxes
    document.querySelectorAll('.appliance-checkbox').forEach(checkbox => {
        const card = checkbox.closest('.appliance-card');
        const details = card.querySelector('.appliance-details');
        const settingsToggle = card.querySelector('.settings-toggle');

        checkbox.addEventListener('change', (e) => {
            details.style.display = e.target.checked ? 'block' : 'none';
            settingsToggle.style.display = e.target.checked ? 'block' : 'none';
        });

        // Handle quantity range
        const quantityRange = card.querySelector('.quantity-range');
        const quantityValue = card.querySelector('.quantity-value');
        const qtyButtons = card.querySelectorAll('.qty-adjust');

        quantityRange.addEventListener('input', (e) => {
            quantityValue.textContent = e.target.value;
        });

        qtyButtons.forEach(btn => {
            btn.addEventListener('click', (e) => {
                const action = e.target.dataset.action;
                const currentValue = parseInt(quantityRange.value);
                if (action === 'increase' && currentValue < 10) {
                    quantityRange.value = currentValue + 1;
                } else if (action === 'decrease' && currentValue > 1) {
                    quantityRange.value = currentValue - 1;
                }
                quantityValue.textContent = quantityRange.value;
            });
        });

        // Handle hours range
        const hoursRange = card.querySelector('.hours-range');
        const hoursValue = card.querySelector('.hours-value');
        const presetButtons = card.querySelectorAll('.usage-presets .btn');

        hoursRange.addEventListener('input', (e) => {
            hoursValue.textContent = e.target.value;
            // Reset active state of preset buttons
            presetButtons.forEach(btn => btn.classList.remove('active'));
        });

        presetButtons.forEach(btn => {
            btn.addEventListener('click', (e) => {
                const hours = parseInt(e.target.dataset.hours);
                hoursRange.value = hours;
                hoursValue.textContent = hours;
                // Update active state
                presetButtons.forEach(b => b.classList.remove('active'));
                e.target.classList.add('active');
            });
        });
    });

    // Form submission
    const form = document.getElementById('savings-form');
    form.addEventListener('submit', (e) => {
        e.preventDefault();
        calculateAdvancedSolution();
    });
} 